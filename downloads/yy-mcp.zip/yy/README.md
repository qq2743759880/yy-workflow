# YY — 当前架构与入口

YY 是 owner 可驾驶的多 Agent 编排工作流。宿主通过 Decision Packet 获得阶段准入与有界任务 brief，再执行任务。本文提供当前架构导航；决策语义以冻结契约为准，项目身份与验收状态见 `plans/project-handoff.md`。

发行版本以 `package.json` 为源，`SKILL.md` 的 `metadata.version` 与它保持一致。许可证标识为 `MIT`，原归属与许可证保留在 `LICENSE`；历史版本和旧里程碑只作演进记录。

## 执行路径

```text
用户 /yy 0..5、/yy research、冻结自然语言触发
  → SKILL.md / commands/*.md（发现与使用指引）
  → scripts/host-adapter.mjs（本地 Core/CLI；MCP 宿主可选 V2 transport）
  → contracts/generated/decision-intent-map.json（冻结映射）
  → Decision Core：stage 准入 → 需要时 task 决策与资产 brief
  → 宿主展示完整 Decision Packet，保存后复核
  → 允许时执行 → 独立任务行为 checker → legacy V1 执行证据
```

研究入口沿用 command frontmatter 的 1.5，仍由 Core 准入并要求真实 research proof。命令文件、旧 journey 快照和只读诊断返回不授予执行许可。具体调用、session 绑定与 `HOST_INTEGRATION_BYPASS` 处理见 `reference/decision-interface.md`。

## 模块与权威边界

| 层 | 当前入口 / 事实来源 | 职责 |
|---|---|---|
| Skill / 用户命令 | `SKILL.md`、`commands/` | 按需加载、导航和宿主接入指引 |
| 宿主 adapter | `scripts/lib/host-adapter.mjs`、`scripts/host-adapter.mjs` | 消费意图映射、调用 Decision、展示与复核 packet；不复制准入或 selector |
| Decision 语义 | `contracts/decision-contract-v1.yaml`、`scripts/lib/decision-core.mjs` | 阶段、journey、路由、资产 eligibility、owner projection 与只读包 |
| 资产与激活 | `vendor/`、`contracts/v3/`、`contracts/asset-manifest-v2.json`、`scripts/lib/activation.mjs` | 方法论载荷、契约元数据、能力 owner 与 brief；vendor 固定随包读取 |
| 执行与恢复 | `scripts/lib/runtime.mjs`、`orchestrator.mjs`、`store.mjs` | child desc 为执行任务、原子 checkpoint、resume、fail-fast settlement |
| Receipt | `scripts/host-consumption.mjs`、`scripts/lib/receipt.mjs` | LEGACY_V1_ONLY；任务行为证据不等于方法论 APPLIED / VERIFIED |
| MCP | `integrations/yy-web-mcp/` | 同进程双挂载、共享认证与可信 workflow binding，均只读 |
| 页面手册 | `scripts/build-guide-content.mjs` → `webview/journey/content.js` | 从当前命令与资产元数据生成导航；页面不授予执行许可 |

MCP `/mcp-v2` 的三个工具与本地 Core 使用相同决策语义。`/mcp` 保持六工具 ABI，属于 **LEGACY_COMPATIBILITY**，读取显式固定的旧工作树；它不代表当前 canonical 阶段权威。说明见 `reference/m1-authority-boundary.md` 和 integration README。

C4 adapter 已有独立验收记录；后续新字节不能继承旧版本验收。C5 尚未交付 methodology writer；执行观察及独立任务 checker 不能升格为 Receipt v2 T6/T7。详见 `reference/receipt-mode-boundary.md`。

## 安装与运行

将发行包解压为独立 YY 目录，并将该目录交给宿主作为 Skill 根目录。迁移使用 `scripts/export-package.mjs --out <新目录> --profile core|mcp`，输出自包含文件与 SHA-256 清单，不修改现有安装。Core 决策默认读取随包契约与资产，MCP V2 默认读取自身发行目录；M1 的旧 pin 通过独立可信位置配置迁移。逐目录职责、排除项和迁移步骤见 `docs/directory-map.md`。环境变量的唯一说明见 `reference/variables-and-config.md`，首次使用见 `ONBOARDING.md`。

```text
node "$SKILL_DIR/scripts/validate-structure.mjs"
node "$SKILL_DIR/scripts/host-adapter.mjs" prepare --workspace "$PROJECT_ROOT" --intent "当前进度"
```

进度查询不授权执行。MCP 使用已有 `integrations/yy-web-mcp/start-yy-mcp.ps1` lifecycle；启动、OAuth、production binding 与 ngrok 配置见 integration README。生产准入需要其自身证据。

命令元数据变化后运行 `npm run guide:build` 刷新页面手册，再运行 `npm run test:guide`；该检查也已接入现有回归入口。

## 文档导航与保留范围

| 要查什么 | 入口 |
|---|---|
| 当前架构 | 本 README |
| 当前身份、验收边界、待办 | `plans/project-handoff.md` |
| Skill 触发与按需协议 | `SKILL.md` 与 `reference/` |
| 宿主 / MCP Decision 调用 | `reference/decision-interface.md` |
| 服务配置与运维 | `integrations/yy-web-mcp/README.md` |
| 上游演进和旧验收 | `CHANGELOG.md`、`docs/history/`、日期化证据 |

`docs/history/`、`plans/` 与 `test-reports/` 中仍有固定测试和证据引用，不能按日期整体删除。逐目录职责和清理依据见 `docs/directory-map.md`。停用文件及编辑前字节统一保存到 `<private-backup-root>/20261004-portability/`；上轮归档也按原字节移入本批。外部冷归档不位于源码搜索、上下文或导出树内，恢复只按本批 manifest。
