"""vulnerable_app.py — AS-2-security 影子跑夹具（canonical，Python）。

六类确定性可检漏洞（自研 semgrep 规则逐类一条，零许可风险）：
  1. hardcoded-api-key      硬编码 API 密钥
  2. hardcoded-password     硬编码口令
  3. sql-injection-concat   SQL 拼接注入（字符串连接进 execute）
  4. weak-hash-md5          弱哈希 MD5 用于凭据摘要
  5. eval-usage             eval 动态执行不可信输入
  6. subprocess-shell-true  subprocess shell=True 命令注入面
"""

import hashlib
import random
import subprocess


# 1. hardcoded-api-key
API_KEY = "sk-live-abcdef1234567890qrstuv"

# 2. hardcoded-password
password = "Sup3rS3cret!"


def login(user_id):
    # 3. sql-injection-concat
    query = "SELECT * FROM users WHERE id = " + user_id
    return db_cursor().execute(query)


def digest_secret(secret):
    # 4. weak-hash-md5
    return hashlib.md5(secret.encode()).hexdigest()


def run_user_expression(expression):
    # 5. eval-usage
    return eval(expression)


def cleanup_temp(path_from_request):
    # 6. subprocess-shell-true
    command = "rm -rf " + path_from_request
    return subprocess.run(command, shell=True)


def issue_token():
    # 附带弱点（不在六类主断言内，属 new_findings 容许面）：
    # 非加密安全随机数用于令牌生成
    return str(random.random())
